1. Run the XNA 4_redist.msi to ensure you have the XNA framework installed
2. Run setup.exe
3. You can start the game with Get Money Game.application after 
the installation is finished 